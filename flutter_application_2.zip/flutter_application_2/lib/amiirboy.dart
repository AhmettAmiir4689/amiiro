import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class Amiir extends StatelessWidget {
  const Amiir({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: SafeArea(
        child: Column(
          children: [
            fatix(IMG: 'images/pizza1.jpg',name: 'Pizza 1',),
            SizedBox(height: 20,),
            fatix(IMG: 'images/pizza2.jpg',name: 'Pizza 2',),
            SizedBox(height: 20,),
            fatix(IMG: 'images/pizza3.jpg',name: 'Pizza 3',)
          ],
        )
        ),
    );
  }
}

class fatix extends StatelessWidget {
  const fatix({
    Key? key, required this.IMG, required this.name,
  }) : super(key: key);
final String IMG;
final String name;
  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Container(
        margin: EdgeInsets.only(top: 20,left: 20,right: 20),
        padding: EdgeInsets.only(left: 20,bottom: 10,top: 10),
        decoration: BoxDecoration(
          color: Colors.white
        ),
        child: Row(
          children: [
            ClipOval(child: Image.asset(IMG,height: 100,width: 100,fit: BoxFit.cover,)),
            Container(margin: EdgeInsets.only(left: 20), child: Column(
              children: [
                Text(name,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: Colors.black),),
              ],
            ))
          ],
        ),

      ),
    );
  }
}